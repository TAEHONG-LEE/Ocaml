#include <stdio.h>
#include <tcl.h>
int main (){
	puts(TCL_VERSION);
	return 0;
}
