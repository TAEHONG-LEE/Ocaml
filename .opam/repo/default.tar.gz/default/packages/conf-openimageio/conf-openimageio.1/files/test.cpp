#include <OpenImageIO/version.h>

#if OIIO_VERSION_MAJOR < 2
#error "OpenImageIO (>= 2.0) is not accessible"
#endif
