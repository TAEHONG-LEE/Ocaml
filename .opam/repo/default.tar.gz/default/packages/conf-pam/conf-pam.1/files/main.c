#include <security/pam_appl.h>
#include <security/pam_modules.h>
static int missing_on_bsd = PAM_XDISPLAY;
int main() { return 0; }
